import os
from dotenv import load_dotenv

# Load .env file (Docker Compose can override this with --env-file)
load_dotenv()


class Config:
    DEBUG = False
    GOOGLE_CREDENTIALS = os.getenv("GOOGLE_APPLICATION_CREDENTIALS")

    @classmethod
    def validate(cls):
        """Fail fast if critical config is missing."""
        missing = []

        if not getattr(cls, "PROJECT_ID", None):
            missing.append("PROJECT_ID")
        if not getattr(cls, "BUCKET_NAME", None):
            missing.append("BUCKET_NAME")
        if not cls.GOOGLE_CREDENTIALS:
            missing.append("GOOGLE_APPLICATION_CREDENTIALS (not set)")
        elif not os.path.exists(cls.GOOGLE_CREDENTIALS):
            missing.append(f"GOOGLE_APPLICATION_CREDENTIALS file not found at {cls.GOOGLE_CREDENTIALS}")

        if missing:
            raise RuntimeError(
                f"Missing required config values: {', '.join(missing)}.\n"
                "Please fix your env vars or docker-compose.yml before running the app."
            )


class DevelopmentConfig(Config):
    DEBUG = True
    SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret-placeholder")
    DATABASE_URI = os.getenv("DATABASE_URI")
    API_KEY = os.getenv("API_KEY", "changeme-dev-secret")
    PROJECT_ID = os.getenv("PROJECT_ID", "elt-datapipeline-dev")
    LOCATION = os.getenv("LOCATION", "us-central1")
    BUCKET_NAME = os.getenv("BUCKET_NAME", "veo-video-dev")
    VEO_MODEL_ID = os.getenv("VEO_MODEL_ID", "imagen-3.0-generate-001")
    DEFAULT_ASPECT_RATIO = os.getenv("DEFAULT_ASPECT_RATIO", "16:9")
    DEFAULT_DURATION = os.getenv("DEFAULT_DURATION", "8s")


class ProductionConfig(Config):
    SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret-placeholder")
    DATABASE_URI = os.getenv("DATABASE_URI")
    API_KEY = os.getenv("API_KEY", "changeme-dev-secret")
    PROJECT_ID = os.getenv("PROJECT_ID", "elt-datapipeline-dev")
    LOCATION = os.getenv("LOCATION", "us-central1")
    BUCKET_NAME = os.getenv("BUCKET_NAME", "veo-video-dev")
    VEO_MODEL_ID = os.getenv("VEO_MODEL_ID", "imagen-3.0-generate-001")
    DEFAULT_ASPECT_RATIO = os.getenv("DEFAULT_ASPECT_RATIO", "16:9")
    DEFAULT_DURATION = os.getenv("DEFAULT_DURATION", "8s")
