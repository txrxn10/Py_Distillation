from app.config import Config
from flask import Flask
from app.routes import get_blueprints


def create_app(config_class=Config):
    app = Flask(__name__)
    
    app.config.from_object(config_class)

    for bp in get_blueprints():
        app.register_blueprint(bp,url_prefix="/api")
        
    return app

app = create_app()