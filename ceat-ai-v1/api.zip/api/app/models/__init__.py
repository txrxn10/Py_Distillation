# from flask_sqlalchemy import SQLAlchemy

# db = SQLAlchemy()

# # Import models here to ensure they are registered with SQLAlchemy
# from .user import User
# from .post import Post
# # Add other models as needed