import os
import uuid
from flask import Blueprint, request
from app.services.video import generate_full_video
from app.utils.response import success_response, error_response
from marshmallow import Schema, fields, ValidationError
from app.services.video import generate_video_clip
from app.utils.stitch_videos import stitch_videos,stitch_with_transitions


class SingleClipSchema(Schema):
    prompt = fields.String(required=True)
    duration = fields.String(required=True)   
 


class MultiSceneSchema(Schema):
    scenes = fields.List(fields.Dict(required=True), required=True)
    stitch = fields.Boolean(load_default=False)
    transitions = fields.Boolean(load_default=False)



video_bp = Blueprint("video", __name__)


@video_bp.route("/video/generate", methods=["POST"])
# def generate_video():
#     """
#     Generate videos from Gemini-generated scenes.
#     Supports stitching if 'stitch': true is passed.
#     """
#     data = request.json or {}
#     scenes = data.get("scenes", [])
#     stitch_flag = data.get("stitch", False)

#     if not scenes:
#         return error_response("No scenes provided", 400)

#     try:
#         generated_clips = []
#         for scene in scenes:
#             uri = generate_video_clip(scene["prompt"], scene["duration"])
#             generated_clips.append({"id": scene["id"], "uri": uri})

#         # Auto stitch if requested
#         if stitch_flag:
#             output_path = os.path.join("/tmp", "final_stitched.mp4")
#             uris = [clip["uri"] for clip in generated_clips]
#             final_uri = stitch_with_transitions(uris, output_path)
#             return success_response(
#                 {"clips": generated_clips, "final_video": final_uri},
#                 message="Videos generated and stitched successfully"
#             )

#         return success_response(
#             {"clips": generated_clips},
#             message="Videos generated successfully"
#         )

#     except Exception as e:
#         return error_response(str(e), 500)

def generate_video():
    """
    POST /video/generate
    - If 'prompt' is provided → generate a single clip.
    - If 'scenes' is provided → generate multiple clips and optionally stitch.
    """
    data = request.get_json() or {}

    try:
        if "prompt" in data:  # -------- SINGLE CLIP MODE --------
            schema = SingleClipSchema()
            errors = schema.validate(data)
            if errors:
                return error_response("Validation failed", 400, errors)

            url_info = generate_video_clip(data["prompt"], data["duration"],folder_id=str(uuid.uuid4()).replace("-", ""))
            return success_response(
                {"clip": url_info},
                message="Video clip generated successfully"
            )

        elif "scenes" in data:  # -------- MULTI-SCENE MODE --------
            schema = MultiSceneSchema()
            errors = schema.validate(data)
            if errors:
                return error_response("Validation failed", 400, errors)

            result = generate_full_video(
                data["scenes"],
                stitch=data.get("stitch", False),
                transitions=data.get("transitions", False)
            )
            return success_response(
                result,
                message="Multi-scene video generated successfully"
            )

        else:
            return error_response(
                "Invalid request: provide either 'prompt' or 'scenes'.", 400
            )

    except Exception as e:
        return error_response(str(e), 500)
    

@video_bp.route("/videos/stitch", methods=["POST"])
def stitch_route():
    """
    Accepts a list of video URIs and stitches them into one final video.
    """
    data = request.json or {}
    uris = data.get("uris", [])

    if not uris:
        return error_response("No URIs provided for stitching", 400)

    try:
        output_path = os.path.join("/tmp", "final_stitched.mp4")
        final_uri = stitch_videos(uris, output_path)
        return success_response(
            {"final_video": final_uri},
            message="Videos stitched successfully"
        )
    except Exception as e:
        return error_response(str(e), 500)