from flask import Blueprint, jsonify

image_bp = Blueprint('image', __name__)

@image_bp.route('/image', methods=['GET'])
def image():
    return jsonify({"message": "This is the image endpoint"})