def get_blueprints():
    from .image_route import image_bp
    from .video_route import video_bp
    from .prompt_route import prompts_bp
    from .bucket_route import bucket_bp
    return [image_bp, video_bp,prompts_bp,bucket_bp]
