from flask import Blueprint, request
from app.services.gemini import generate_enhanced_prompt
from app.utils.response import success_response, error_response
from app.schemas.prompt_schema import PromptSchema

prompts_bp = Blueprint("prompts", __name__)
schema = PromptSchema()

@prompts_bp.route("/prompts/generate", methods=["POST"])
def generate_prompt():
    json_data = request.get_json() or {}

    # Validate input
    errors = schema.validate(json_data)
    if errors:
        return error_response("Validation failed", 400, errors)

    try:
        enhanced_prompt = generate_enhanced_prompt(json_data)
        return success_response(
            {"prompt": enhanced_prompt},
            message="Prompt generated successfully"
        )
    except Exception as e:
        return error_response(str(e), 500)
