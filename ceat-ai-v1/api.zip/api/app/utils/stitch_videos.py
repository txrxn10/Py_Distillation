import os
import subprocess
from typing import List


def stitch_videos(video_paths: List[str], output_path: str) -> str:
    """
    Stitches multiple video clips into a single video (simple concat).
    """
    if not video_paths:
        raise ValueError("No video paths provided for stitching.")

    list_file = "videos_to_stitch.txt"
    with open(list_file, "w") as f:
        for path in video_paths:
            if not os.path.exists(path):
                raise FileNotFoundError(f"Video file not found: {path}")
            f.write(f"file '{path}'\n")

    command = [
        "ffmpeg", "-f", "concat", "-safe", "0",
        "-i", list_file, "-c", "copy", "-y", output_path
    ]

    try:
        subprocess.run(command, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"FFmpeg stitching failed: {e.stderr.decode()}")

    os.remove(list_file)
    return output_path


def stitch_with_transitions(video_paths: List[str], output_path: str, transition_duration: float = 1.0) -> str:
    """
    Stitches videos with smooth crossfade transitions.
    Re-encodes videos → higher quality but slower.
    """
    if len(video_paths) < 2:
        return stitch_videos(video_paths, output_path)

    inputs = []
    filter_parts = []
    for i, path in enumerate(video_paths):
        inputs.extend(["-i", path])
        filter_parts.append(f"[{i}:v]scale=1920:1080,setsar=1[v{i}];[{i}:a]aformat=fltp44100[a{i}]")

    xfade_cmd = ""
    acrossfade_cmd = ""
    last_v, last_a = "[v0]", "[a0]"

    for i in range(1, len(video_paths)):
        v_label, a_label = f"[v{i}]", f"[a{i}]"
        next_v, next_a = f"[vout{i}]", f"[aout{i}]"

        # offset assumes ~8s clips
        xfade_cmd += f"{last_v}{v_label}xfade=transition=fade:duration={transition_duration}:offset=7s{next_v};"
        acrossfade_cmd += f"{last_a}{a_label}acrossfade=d={transition_duration}{next_a};"

        last_v, last_a = next_v, next_a

    filter_complex = ";".join(filter_parts) + ";" + xfade_cmd + acrossfade_cmd

    cmd = [
        "ffmpeg", "-y",
        *inputs,
        "-filter_complex", filter_complex,
        "-map", last_v,
        "-map", last_a,
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "18",
        "-c:a", "aac", "-b:a", "192k",
        output_path,
    ]

    try:
        subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"FFmpeg transitions failed: {e.stderr.decode()}")

    return output_path
