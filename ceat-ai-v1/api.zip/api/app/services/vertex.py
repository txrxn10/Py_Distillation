from google.cloud import aiplatform
from flask import current_app


_prediction_client = None

def client():
    global _prediction_client
    if _prediction_client is None:
        _prediction_client = aiplatform.gapic.PredictionServiceClient()
    return _prediction_client

def _endpoint():
    cfg = current_app.config
    endpoint = f"projects/{cfg['PROJECT_ID']}/locations/{cfg['LOCATION']}/publishers/google/models/{cfg['VEO_MODEL_ID']}"
    print("DEBUG Endpoint:", endpoint)
    return endpoint

def generate_video(prompt: str, aspect_ratio: str, duration: str, output_gcs_uri: str):
    instances = [{
        "prompt": prompt,
        "aspect_ratio": aspect_ratio,
        "duration": duration,
        "output_gcs_uri": output_gcs_uri,
    }]
    response = client().predict(endpoint=_endpoint(), instances=instances, parameters={})
    return response.predictions[0].get("uri")

def extend_video(video_uri: str, prompt: str, aspect_ratio: str, duration: str, output_gcs_uri: str):
    instances = [{
        "video": video_uri,
        "prompt": prompt,
        "aspect_ratio": aspect_ratio,
        "duration": duration,
        "output_gcs_uri": output_gcs_uri,
    }]
    response = client().predict(endpoint=_endpoint(), instances=instances, parameters={})
    return response.predictions[0].get("uri")
