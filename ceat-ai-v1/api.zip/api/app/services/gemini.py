import os
import vertexai
import json
import re
from vertexai.generative_models import GenerativeModel
from app.config import DevelopmentConfig
from app.brand_rules import brand_rules


def get_gemini_model():
    """Initialize and return the Gemini model client."""
    project_id = os.getenv("PROJECT_ID", DevelopmentConfig.PROJECT_ID)
    location = os.getenv("LOCATION", DevelopmentConfig.LOCATION)
    vertexai.init(project=project_id, location=location)
    return GenerativeModel("gemini-2.5-pro")

def get_veo_model():
    """Initialize Veo 3 video generation model."""
    project_id = os.getenv("PROJECT_ID", DevelopmentConfig.PROJECT_ID)
    location = os.getenv("LOCATION", DevelopmentConfig.LOCATION)
    vertexai.init(project=project_id, location=location)
    return GenerativeModel("veo-3.0-generate-001")


# def build_prompt(fields: dict) -> str:
#     """Builds the structured prompt for Gemini based on mode and inputs."""

#     mode = fields["mode"]

#     subject = fields.get("subject", "")
#     action = fields.get("action", "")
#     scene = fields.get("scene", "")
#     camera = fields.get("camera_angles", "")
#     movement = fields.get("camera_movements", "")
#     style = fields.get("visual_style", "").strip() or "cinematic"
#     lens_effects = fields.get("lens_effects", "")
#     temporal = fields.get("temporal_elements", "")
#     sound = fields.get("sound_effects", "")
#     dialogue = fields.get("dialogue", "")

#     if mode == "image_to_video":
        
#         image_ref = fields.get("image_url", "")
#         if not image_ref:
#             raise ValueError("image_url is required for image_to_video mode.")

#         user_input = f"""
#         Image Reference: {image_ref}
#         Action: {action}
#         Scene/Context: {scene}
#         Camera Angles: {camera}
#         Camera Movements: {movement}
#         Visual Style: {style}
#         Lens & Optical Effects: {lens_effects}
#         Temporal Elements: {temporal}
#         Sound Effects & Ambience: {sound}
#         Dialogue: {dialogue}
#         """

#         task_instruction = f"Enhance cinematic storytelling using the given reference image as the base. Write a SINGLE {style} video prompt in plain descriptive text."

#     else:   
#         user_input = f"""
#         Subject: {subject}
#         Action: {action}
#         Scene/Context: {scene}
#         Camera Angles: {camera}
#         Camera Movements: {movement}
#         Visual Style: {style}
#         Lens & Optical Effects: {lens_effects}
#         Temporal Elements: {temporal}
#         Sound Effects & Ambience: {sound}
#         Dialogue: {dialogue}
#         """

#         task_instruction = f"Create a SINGLE {style} video prompt entirely from text inputs. Output must be plain descriptive text only."

#     return f"""
#     {brand_rules}

#     Task: {task_instruction}

#     Inputs:
#     {user_input}

#     Output only the final {style} video prompt text, without additional headings or formatting.
#     """


# def generate_enhanced_prompt(fields: dict) -> str:
#     """Generate an enhanced video prompt using Gemini."""
#     model = get_gemini_model()
#     final_prompt = build_prompt(fields)
#     response = model.generate_content(final_prompt)
#     return response.text.strip()

# def build_prompt(fields: dict) -> str:
#     """Build the instruction prompt for Gemini to generate structured scene JSON."""

#     mode = fields["mode"]

#     # Shared fields
#     subject = fields.get("subject", "")
#     action = fields.get("action", "")
#     scene = fields.get("scene", "")
#     camera = fields.get("camera_angles", "")
#     movement = fields.get("camera_movements", "")
#     style = fields.get("visual_style", "")
#     lens_effects = fields.get("lens_effects", "")
#     temporal = fields.get("temporal_elements", "")
#     sound = fields.get("sound_effects", "")
#     dialogue = fields.get("dialogue", "")

#     if mode == "image_to_video":
#         image_ref = fields.get("image_url", "")
#         if not image_ref:
#             raise ValueError("image_url is required for image_to_video mode.")

#         user_input = f"""
#         Image Reference: {image_ref}
#         Action: {action}
#         Scene/Context: {scene}
#         Camera Angles: {camera}
#         Camera Movements: {movement}
#         Visual Style & Aesthetics: {style}
#         Lens & Optical Effects: {lens_effects}
#         Temporal Elements: {temporal}
#         Sound Effects & Ambience: {sound}
#         Dialogue: {dialogue}
#         """

#         task_instruction = "Break down into cinematic storytelling scenes using the given reference image."

#     else:  # text_to_video
#         user_input = f"""
#         Subject: {subject}
#         Action: {action}
#         Scene/Context: {scene}
#         Camera Angles: {camera}
#         Camera Movements: {movement}
#         Visual Style & Aesthetics: {style}
#         Lens & Optical Effects: {lens_effects}
#         Temporal Elements: {temporal}
#         Sound Effects & Ambience: {sound}
#         Dialogue: {dialogue}
#         """

#         task_instruction = "Break down into cinematic storytelling scenes entirely from text inputs."

#     return f"""
#     {brand_rules}

#     Task: {task_instruction}

#     Inputs:
#     {user_input}

#     --- OUTPUT INSTRUCTIONS ---
#     - Output STRICT JSON (no markdown, no explanations).
#     - JSON must contain a "scenes" array.
#     - Each scene must include:
#         - "id": numeric order of the scene
#         - "duration": max 8s (string, e.g., "8s")
#         - "prompt": the cinematic description for Veo
#     - Provide 4-5 scenes that together form a smooth 30-40 second cinematic video.
#     - Do NOT add commentary, only return JSON.
#     """


# def generate_enhanced_prompt(fields: dict) -> dict:
#     """Generate structured multi-scene cinematic prompt JSON from Gemini."""
#     model = get_gemini_model()
#     final_prompt = build_prompt(fields)
#     response = model.generate_content(final_prompt)
#     raw_text = response.text.strip()

#     try:
#         parsed = json.loads(raw_text)
#         return parsed
#     except json.JSONDecodeError:
#         raise ValueError("Gemini did not return valid JSON. Raw response:\n" + raw_text)

# def build_prompt(fields: dict) -> str:
#     """Build the instruction prompt for Gemini to generate structured scene JSON."""

#     mode = fields["mode"]

#     # Shared fields
#     subject = fields.get("subject", "")
#     action = fields.get("action", "")
#     scene = fields.get("scene", "")
#     camera = fields.get("camera_angles", "")
#     movement = fields.get("camera_movements", "")
#     style = fields.get("visual_style", "")
#     lens_effects = fields.get("lens_effects", "")
#     temporal = fields.get("temporal_elements", "")
#     sound = fields.get("sound_effects", "")
#     dialogue = fields.get("dialogue", "")

#     if mode == "image_to_video":
#         image_ref = fields.get("image_url", "")
#         if not image_ref:
#             raise ValueError("image_url is required for image_to_video mode.")

#         user_input = f"""
#         Image Reference: {image_ref}
#         Action: {action}
#         Scene/Context: {scene}
#         Camera Angles: {camera}
#         Camera Movements: {movement}
#         Visual Style & Aesthetics: {style}
#         Lens & Optical Effects: {lens_effects}
#         Temporal Elements: {temporal}
#         Sound Effects & Ambience: {sound}
#         Dialogue: {dialogue}
#         """

#         task_instruction = "Break down into cinematic storytelling scenes using the given reference image."

#     else:  # text_to_video
#         user_input = f"""
#         Subject: {subject}
#         Action: {action}
#         Scene/Context: {scene}
#         Camera Angles: {camera}
#         Camera Movements: {movement}
#         Visual Style & Aesthetics: {style}
#         Lens & Optical Effects: {lens_effects}
#         Temporal Elements: {temporal}
#         Sound Effects & Ambience: {sound}
#         Dialogue: {dialogue}
#         """

#         task_instruction = "Break down into cinematic storytelling scenes entirely from text inputs."

#     return f"""
#     {brand_rules}

#     Task: {task_instruction}

#     Inputs:
#     {user_input}

#     --- OUTPUT INSTRUCTIONS ---
#     - Output STRICT JSON (no markdown, no explanations).
#     - JSON must contain a "scenes" array.
#     - Each scene must include:
#         - "id": numeric order of the scene
#         - "duration": max 8s (string, e.g., "8s")
#         - "prompt": the cinematic description for Veo
#     - Provide 4-5 scenes that together form a smooth 30-40 second cinematic video.
#     - Do NOT add commentary, only return JSON.
#     """


# def safe_json_parse(raw_text: str) -> dict:
#     """
#     Cleans Gemini's output and ensures valid JSON parsing.
#     Handles cases where output is wrapped in ```json ... ```
#     """
#     # Strip markdown fences if present
#     cleaned = re.sub(r"^```(?:json)?|```$", "", raw_text.strip(), flags=re.MULTILINE).strip()

#     try:
#         return json.loads(cleaned)
#     except json.JSONDecodeError:
#         raise ValueError("Gemini did not return valid JSON. Raw response:\n" + raw_text)


# def generate_enhanced_prompt(fields: dict) -> dict:
#     """Generate structured multi-scene cinematic prompt JSON from Gemini."""
#     model = get_gemini_model()
#     final_prompt = build_prompt(fields)
#     response = model.generate_content(final_prompt)
#     raw_text = response.text.strip()
#     return safe_json_parse(raw_text)


def split_duration(total_duration: int) -> list[int]:
    """
    Split a total duration into scene chunks (each <= 8s).
    Example: 20 -> [6, 5, 5, 4]
    """
    max_scene = 8
    scenes = []
    remaining = total_duration

    while remaining > 0:
        if remaining > max_scene:
            chunk = min(max_scene, remaining // 2)  # balance chunks
        else:
            chunk = remaining
        scenes.append(chunk)
        remaining -= chunk

    return scenes


def build_prompt(fields: dict, scene_durations: list[int]) -> str:
    """Build the instruction prompt for Gemini with fixed scene durations."""

    mode = fields["mode"]

    # Shared fields
    subject = fields.get("subject", "")
    action = fields.get("action", "")
    scene = fields.get("scene", "")
    camera = fields.get("camera_angles", "")
    movement = fields.get("camera_movements", "")
    style = fields.get("visual_style", "")
    lens_effects = fields.get("lens_effects", "")
    temporal = fields.get("temporal_elements", "")
    sound = fields.get("sound_effects", "")
    dialogue = fields.get("dialogue", "")

    if mode == "image_to_video":
        image_ref = fields.get("image_url", "")
        if not image_ref:
            raise ValueError("image_url is required for image_to_video mode.")

        user_input = f"""
        Image Reference: {image_ref}
        Action: {action}
        Scene/Context: {scene}
        Camera Angles: {camera}
        Camera Movements: {movement}
        Visual Style & Aesthetics: {style}
        Lens & Optical Effects: {lens_effects}
        Temporal Elements: {temporal}
        Sound Effects & Ambience: {sound}
        Dialogue: {dialogue}
        """
        task_instruction = "Break down into cinematic storytelling scenes using the given reference image."

    else:  # text_to_video
        user_input = f"""
        Subject: {subject}
        Action: {action}
        Scene/Context: {scene}
        Camera Angles: {camera}
        Camera Movements: {movement}
        Visual Style & Aesthetics: {style}
        Lens & Optical Effects: {lens_effects}
        Temporal Elements: {temporal}
        Sound Effects & Ambience: {sound}
        Dialogue: {dialogue}
        """
        task_instruction = "Break down into cinematic storytelling scenes entirely from text inputs."

    return f"""
    {brand_rules}

    Task: {task_instruction}

    Inputs:
    {user_input}

    --- OUTPUT INSTRUCTIONS ---
    - Output STRICT JSON (no markdown, no explanations).
    - JSON must contain a "scenes" array.
    - Each scene must include:
        - "id": numeric order of the scene
        - "duration": one of these values {scene_durations} (in seconds, integer)
        - "prompt": the cinematic description for Veo
    - Ensure the sum of durations matches exactly {sum(scene_durations)} seconds.
    - Do NOT add commentary, only return JSON.
    """


def safe_json_parse(raw_text: str) -> dict:
    """
    Cleans Gemini's output and ensures valid JSON parsing.
    Handles cases where output is wrapped in ```json ... ```
    """
    cleaned = re.sub(r"^```(?:json)?|```$", "", raw_text.strip(), flags=re.MULTILINE).strip()

    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        raise ValueError("Gemini did not return valid JSON. Raw response:\n" + raw_text)


def generate_enhanced_prompt(fields: dict) -> dict:
    """Generate structured cinematic prompt JSON from Gemini."""
    model = get_gemini_model()

    total_duration = int(fields.get("duration", 8))
    if total_duration <= 8:
        scene_durations = [total_duration]
    else:
        scene_durations = split_duration(total_duration)

    final_prompt = build_prompt(fields, scene_durations)
    response = model.generate_content(final_prompt)
    raw_text = response.text.strip()
    return safe_json_parse(raw_text)