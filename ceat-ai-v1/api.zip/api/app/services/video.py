# import uuid
# import os
# import tempfile
# from google.cloud import storage
# from app.services.gemini import get_veo_model
# from app.utils.stitch_videos import stitch_videos, stitch_with_transitions
# from app.config import DevelopmentConfig


# def upload_to_gcs(local_path: str, bucket_name: str, object_name: str) -> dict:
#     """
#     Upload a file to Google Cloud Storage and return gs:// URI + signed URL.
#     """
#     client = storage.Client()
#     bucket = client.bucket(bucket_name)
#     blob = bucket.blob(object_name)
#     blob.upload_from_filename(local_path, content_type="video/mp4")

#     gs_uri = f"gs://{bucket_name}/{object_name}"

#     # Signed URL (7 days = 604800 seconds)
#     signed_url = blob.generate_signed_url(expiration=604800)

#     return {"gs_uri": gs_uri, "signed_url": signed_url}


# def generate_video_clip(prompt: str, duration: str, folder_id: str, index: int = 0) -> dict:
#     """
#     Generate a single video clip from a prompt + duration using Veo 3.
#     Saves locally, uploads to GCS as video/<folder_id>/sample_<index>.mp4.
#     Returns dict {gs_uri, signed_url}.
#     """
#     model = get_veo_model()
#     bucket_name = os.getenv("BUCKET_NAME", DevelopmentConfig.BUCKET_NAME)

#     # Local temp path
#     local_path = os.path.join(tempfile.gettempdir(), f"{uuid.uuid4()}.mp4")
#     object_name = f"video/{folder_id}/sample_{index}.mp4"

#     try:
#         # Call Veo model
#         response = model.generate_content(
#         prompt,
#         video_generation_config={
#             "duration_seconds": int(duration.replace("s", "")),  # e.g. "8s" -> 8
#             "aspect_ratio": "16:9",
#             "mime_type": "video/mp4",
#         }
#     )

#         # Validate response
#         if not response or not response.candidates:
#             raise RuntimeError("Veo did not return a video candidate.")

#         candidate = response.candidates[0]
#         if not hasattr(candidate, "video") or not candidate.video:
#             raise RuntimeError("Veo response missing video content.")

#         # Save video to temp file
#         with open(local_path, "wb") as f:
#             f.write(candidate.video)

#         # Upload to GCS
#         return upload_to_gcs(local_path, bucket_name, object_name)

#     finally:
#         if os.path.exists(local_path):
#             os.remove(local_path)


# # def generate_full_video(scenes: list, stitch: bool = False, transitions: bool = False) -> dict:
# #     """
# #     Generate clips for each scene and optionally stitch them into one final video.
# #     Returns dict with signed URLs.
# #     """
# #     bucket_name = os.getenv("BUCKET_NAME", DevelopmentConfig.BUCKET_NAME)
# #     generated_clips = []

# #     # Step 1: Generate each scene
# #     local_clips = []
# #     for scene in scenes:
# #         model = get_veo_model()
# #         local_path = os.path.join(tempfile.gettempdir(), f"{uuid.uuid4()}.mp4")

# #         try:
# #             response = model.generate_content(
# #                 scene["prompt"],
# #                 generation_config={
# #                     "duration": scene["duration"],
# #                     "aspect_ratio": "16:9",
# #                     "mime_type": "video/mp4",
# #                 }
# #             )

# #             if not response or not response.candidates:
# #                 raise RuntimeError("Veo did not return a video candidate.")

# #             candidate = response.candidates[0]
# #             if not hasattr(candidate, "video") or not candidate.video:
# #                 raise RuntimeError("Veo response missing video content.")

# #             with open(local_path, "wb") as f:
# #                 f.write(candidate.video)

# #             local_clips.append(local_path)
# #             url = upload_to_gcs(local_path, bucket_name)
# #             generated_clips.append({"id": scene["id"], "url": url})

# #         finally:
# #             if os.path.exists(local_path):
# #                 os.remove(local_path)

# #     # Step 2: Optionally stitch
# #     if stitch:
# #         stitched_path = os.path.join(tempfile.gettempdir(), f"final_stitched_{uuid.uuid4()}.mp4")

# #         if transitions:
# #             final_local = stitch_with_transitions(local_clips, stitched_path)
# #         else:
# #             final_local = stitch_videos(local_clips, stitched_path)

# #         # Upload stitched video to GCS
# #         final_url = upload_to_gcs(final_local, bucket_name)

# #         if os.path.exists(final_local):
# #             os.remove(final_local)

# #         return {"clips": generated_clips, "final_video": final_url}

# #     return {"clips": generated_clips}
# def generate_full_video(scenes: list, stitch: bool = False, transitions: bool = False) -> dict:
#     """
#     Generate clips for each scene and optionally stitch them into one final video.
#     Returns dict with gs:// URIs + signed URLs.
#     """
#     bucket_name = os.getenv("BUCKET_NAME", DevelopmentConfig.BUCKET_NAME)
#     folder_id = str(uuid.uuid4()).replace("-", "")  # unique folder for this request
#     generated_clips = []
#     local_clips = []

#     # Step 1: Generate each scene
#     for idx, scene in enumerate(scenes):
#         model = get_veo_model()
#         local_path = os.path.join(tempfile.gettempdir(), f"{uuid.uuid4()}.mp4")
#         object_name = f"video/{folder_id}/sample_{idx}.mp4"

#         try:
#             response = model.generate_content(
#                 scene["prompt"],
#                 video_generation_config={
#                     "duration_seconds": int(scene["duration"].replace("s", "")),
#                     "aspect_ratio": "16:9",
#                     "mime_type": "video/mp4",
#                 }
#             )

#             if not response or not response.candidates:
#                 raise RuntimeError("Veo did not return a video candidate.")

#             candidate = response.candidates[0]
#             if not hasattr(candidate, "video") or not candidate.video:
#                 raise RuntimeError("Veo response missing video content.")

#             with open(local_path, "wb") as f:
#                 f.write(candidate.video)

#             local_clips.append(local_path)

#             upload_info = upload_to_gcs(local_path, bucket_name, object_name)
#             generated_clips.append({"id": scene["id"], **upload_info})

#         finally:
#             if os.path.exists(local_path):
#                 os.remove(local_path)

#     # Step 2: Optionally stitch
#     if stitch and local_clips:
#         stitched_path = os.path.join(tempfile.gettempdir(), f"final_stitched_{uuid.uuid4()}.mp4")
#         final_object = f"video/{folder_id}/final_stitched.mp4"

#         if transitions:
#             final_local = stitch_with_transitions(local_clips, stitched_path)
#         else:
#             final_local = stitch_videos(local_clips, stitched_path)

#         upload_info = upload_to_gcs(final_local, bucket_name, final_object)

#         if os.path.exists(final_local):
#             os.remove(final_local)

#         return {"clips": generated_clips, "final_video": upload_info}

#     return {"clips": generated_clips}



import uuid
import os
import tempfile
import time
from google.cloud import storage
from google import genai
from datetime import timedelta
from google.genai.types import GenerateVideosConfig
from app.config import DevelopmentConfig
from app.utils.stitch_videos import stitch_videos, stitch_with_transitions


def get_genai_client():
    """Return a properly initialized genai.Client for Veo 3."""
    project_id = os.getenv("PROJECT_ID", DevelopmentConfig.PROJECT_ID)
    location = os.getenv("LOCATION", DevelopmentConfig.LOCATION)

    return genai.Client(
        vertexai=True,
        project=project_id,
        location=location,
    )

# def generate_video_clip(prompt: str, duration: str, folder_id: str, index: int = 0) -> dict:
#     """
#     Generate a single video clip with Veo 3 and upload to GCS.
#     Returns dict {gs_uri, signed_url}.
#     """
#     client = get_genai_client()
#     bucket_name = os.getenv("BUCKET_NAME", DevelopmentConfig.BUCKET_NAME)
#     object_name = f"video/{folder_id}/sample_{index}.mp4"
#     output_gcs_uri = f"gs://{bucket_name}/{object_name}"

#     # Start generation
#     operation = client.models.generate_videos(
#         model="veo-3.0-generate-001",
#         prompt=prompt,
#         config=GenerateVideosConfig(
#             aspect_ratio="16:9",
#             output_gcs_uri=output_gcs_uri,
#         ),
#     )

#     # Poll until job finishes
#     while not operation.done:
#         time.sleep(15)
#         operation = client.operations.get(operation)

#     if not operation.response:
#         raise RuntimeError("Veo did not return a video response.")

#     # Get GCS URI
#     gs_uri = operation.result.generated_videos[0].video.uri

#     # Signed URL
#     storage_client = storage.Client()
#     bucket = storage_client.bucket(bucket_name)
#     blob = bucket.blob(object_name)
#     signed_url = blob.generate_signed_url(expiration=604800)

#     return {"gs_uri": gs_uri, "signed_url": signed_url}

def generate_video_clip(prompt: str, duration: str, folder_id: str, index: int = 0) -> dict:
    """
    Generate a single video clip with Veo 3 and upload to GCS.
    Returns dict {gs_uri}.
    """
    client = get_genai_client()
    bucket_name = os.getenv("BUCKET_NAME", DevelopmentConfig.BUCKET_NAME)
    object_name = f"video/{folder_id}/sample_{index}.mp4"

    # Save temporarily
    local_path = f"/tmp/sample_{index}.mp4"

    # Start generation
    operation = client.models.generate_videos(
        model="veo-3.0-generate-001",
        prompt=prompt,
        config=GenerateVideosConfig(
            aspect_ratio="16:9",
            duration=duration,
            output_file=local_path,  # store locally first
        ),
    )

    # Poll until job finishes
    while not operation.done:
        time.sleep(15)
        operation = client.operations.get(operation)

    if not operation.response:
        raise RuntimeError("Veo did not return a video response.")

    # ✅ Upload to GCS
    gs_uri = upload_to_gcs(bucket_name, object_name, local_path)

    return {"gs_uri": gs_uri}


def download_from_gcs(gs_uri: str, local_path: str):
    """Download a GCS object to a local file."""
    storage_client = storage.Client()
    parts = gs_uri.replace("gs://", "").split("/", 1)
    bucket_name, object_name = parts[0], parts[1]
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(object_name)
    blob.download_to_filename(local_path)
    return local_path


# def upload_to_gcs(local_path: str, bucket_name: str, object_name: str) -> dict:
#     """Upload a local file to GCS and return URIs."""
#     client = storage.Client()
#     bucket = client.bucket(bucket_name)
#     blob = bucket.blob(object_name)
#     blob.upload_from_filename(local_path, content_type="video/mp4")

#     gs_uri = f"gs://{bucket_name}/{object_name}"
#     signed_url = blob.generate_signed_url(expiration=604800)
#     return {"gs_uri": gs_uri, "signed_url": signed_url}

# def upload_to_gcs(local_path: str, bucket_name: str, object_name: str) -> dict:
#     """
#     Upload a file to Google Cloud Storage and return gs:// URI + signed URL.
#     """
#     client = storage.Client()
#     bucket = client.bucket(bucket_name)
#     blob = bucket.blob(object_name)
#     blob.upload_from_filename(local_path, content_type="video/mp4")

#     gs_uri = f"gs://{bucket_name}/{object_name}"

#     # ✅ Use timedelta for 7-day signed URL
#     signed_url = blob.generate_signed_url(
#         expiration=timedelta(days=7),
#         method="GET"
#     )

#     return {"gs_uri": gs_uri, "signed_url": signed_url}

def upload_to_gcs(local_path: str, bucket_name: str, object_name: str) -> dict:
    """
    Upload a file to Google Cloud Storage and return gs:// URI + public HTTPS URL.
    """
    from google.cloud import storage

    client = storage.Client()
    bucket = client.bucket(bucket_name)
    blob = bucket.blob(object_name)

    # Upload file
    blob.upload_from_filename(local_path, content_type="video/mp4")

    gs_uri = f"gs://{bucket_name}/{object_name}"
    public_url = f"https://storage.googleapis.com/{bucket_name}/{object_name}"

    return {"gs_uri": gs_uri, "public_url": public_url}


def generate_full_video(scenes: list, stitch: bool = False, transitions: bool = False) -> dict:
    """
    Generate clips for each scene with Veo 3 and optionally stitch them.
    - Downloads clips from GCS
    - Stitches locally
    - Uploads final stitched video back to GCS
    """
    bucket_name = os.getenv("BUCKET_NAME", DevelopmentConfig.BUCKET_NAME)
    folder_id = str(uuid.uuid4()).replace("-", "")
    generated_clips = []

    # Step 1: Generate clips
    for idx, scene in enumerate(scenes):
        clip_info = generate_video_clip(scene["prompt"], scene["duration"], folder_id, idx)
        generated_clips.append({"id": scene["id"], **clip_info})

    # Step 2: Stitch if requested
    if stitch:
        tmp_dir = tempfile.gettempdir()
        local_clips = []

        # Download each clip from GCS
        for clip in generated_clips:
            local_path = os.path.join(tmp_dir, f"{uuid.uuid4()}.mp4")
            download_from_gcs(clip["gs_uri"], local_path)
            local_clips.append(local_path)

        stitched_local = os.path.join(tmp_dir, f"final_stitched_{uuid.uuid4()}.mp4")
        final_object = f"video/{folder_id}/final_stitched.mp4"

        # Run FFmpeg stitching
        if transitions:
            stitched_file = stitch_with_transitions(local_clips, stitched_local)
        else:
            stitched_file = stitch_videos(local_clips, stitched_local)

        # Upload stitched video
        final_upload = upload_to_gcs(stitched_file, bucket_name, final_object)

        # Cleanup
        for path in local_clips:
            if os.path.exists(path):
                os.remove(path)
        if os.path.exists(stitched_file):
            os.remove(stitched_file)

        return {"clips": generated_clips, "final_video": final_upload}

    return {"clips": generated_clips}
