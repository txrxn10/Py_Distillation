from google.cloud import storage

_storage_client = None

def storage_client():
    global _storage_client
    if _storage_client is None:
        _storage_client = storage.Client()
    return _storage_client

def download_gcs_uri(gcs_uri: str, local_path: str):
    assert gcs_uri.startswith("gs://"), "Expected gs:// URI"
    bucket_name, blob_path = gcs_uri.replace("gs://","").split("/", 1)
    bucket = storage_client().bucket(bucket_name)
    blob = bucket.blob(blob_path)
    blob.download_to_filename(local_path)
    return local_path
