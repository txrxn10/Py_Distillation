from marshmallow import Schema, fields, validate, ValidationError


class PromptSchema(Schema):
    mode = fields.Str(
        required=True,
        validate=validate.OneOf(["text_to_video", "image_to_video"])
    )
    subject = fields.Str(required=False, allow_none=True)
    action = fields.Str(required=False, allow_none=True)
    scene = fields.Str(required=False, allow_none=True)
    camera_angles = fields.Str(required=False, allow_none=True)
    camera_movements = fields.Str(required=False, allow_none=True)
    visual_style = fields.Str(required=False, allow_none=True)
    lens_effects = fields.Str(required=False, allow_none=True)
    temporal_elements = fields.Str(required=False, allow_none=True)
    sound_effects = fields.Str(required=False, allow_none=True)
    dialogue = fields.Str(required=False, allow_none=True)
    image_url = fields.Str(required=False, allow_none=True)
    duration = fields.Int(required=False, allow_none=True)
